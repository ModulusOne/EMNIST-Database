
import numpy
import matplotlib.pyplot
get_ipython().magic('matplotlib inline')


# In[6]:


data_file = open('emnist_dataset/emnist_train.csv', 'r')
data_list = data_file.readlines()
data_file.close()


# In[14]:


all_values = data_list[76].split(',')
image_array = numpy.asfarray(all_values[1:]).reshape((28,28))
matplotlib.pyplot.imshow(image_array, cmap='Greys', interpolation='none')

